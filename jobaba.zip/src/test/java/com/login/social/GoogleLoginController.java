package com.login.social;

import com.google.api.client.googleapis.auth.oauth2.GoogleIdToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleIdTokenVerifier;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.gson.GsonFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.Map;

@RestController
public class GoogleLoginController {

    private final String CLIENT_ID = "YOUR_GOOGLE_CLIENT_ID";

    @PostMapping("/login/google")
    public Map<String, Object> loginWithGoogle(@RequestBody Map<String, String> payload) throws Exception {
        String idTokenString = payload.get("idToken");

        // GsonFactory를 사용하여 JsonFactory 인스턴스 생성
        JsonFactory jsonFactory = new GsonFactory();
        GoogleIdTokenVerifier verifier = new GoogleIdTokenVerifier.Builder(
                GoogleNetHttpTransport.newTrustedTransport(),
                jsonFactory
        ).setAudience(Collections.singletonList(CLIENT_ID)).build();

        GoogleIdToken idToken = verifier.verify(idTokenString);
        if (idToken != null) {
            GoogleIdToken.Payload idTokenPayload = idToken.getPayload();
            return Map.of(
                    "name", idTokenPayload.get("name"),
                    "email", idTokenPayload.getEmail()
            );
        } else {
            throw new IllegalArgumentException("Invalid ID token.");
        }
    }
}
