package com.login.social;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class UserController {

    @GetMapping("/login/success")
    public Map<String, Object> getUser(@AuthenticationPrincipal OAuth2User user) {
        return Map.of(
            "name", user.getAttribute("name"),
            "email", user.getAttribute("email")
        );
    }
}
